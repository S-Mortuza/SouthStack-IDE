# Init for results
